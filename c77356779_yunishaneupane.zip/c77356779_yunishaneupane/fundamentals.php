<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Web Applications and Technologies</title>
      <link type="text/css" rel="stylesheet" href="main.css" />
   </head>
   <body>
      <header>
         <h1>Paul Doney C123457</h1> 
      </header>
      
      <section id="container">
         <h1>Fundamentals of PHP</h1>
         <h2>Selection</h2>

         <?php
    $day=date('l');
    echo 'it\'s '.$day.'<br>';

    if($day =="Wednesday"){
        echo "it's midweek";
    }	
    else{
        echo"it's not midweek";
    }	
    echo"<br>";

    $hour=date('H');
    if($hour<12){
        echo "Good Morning!"."<br>";
        }
        elseif ($hour>=12 && $hour<=18) {
            echo "Good Afternoon!"."<br>";
            }
            else {
                echo "Good Night!"."<br>";
    }
    echo"<br>";
    
    $password='password';

    if(strlen($password)>4 && strlen($password)<10){
        echo "Password length is valid.<br>";
    }
        else{
            echo "Password length is invalid.<br>";
        }
        
        if($password == 'password' || $password == 'username'){
            echo "Password valid";
        }else{
            echo"Password invalid";
        }
        echo '<br>';  echo"<br>";
        
    
    //Additional Task
    //Ticket company

    $ticketPrice=25;
    $age=15;
    $isMember=true;

    if($age<12){
        $ticketPrice*=0.5;
    }
    elseif($age<18){
        $ticketPrice*=0.75;
    }
    elseif($age>=65){
        $ticketPrice*=0.75;        

    }

    if($isMember){
        $ticketPrice*=0.9;
    }

    $finalticketprice= number_format($ticketPrice,2);
    
    echo "Initial Ticket Price:25"."<br>";
    echo "Age:".$age."<br>";
    echo "Member:".($isMember? 'Yes':'No')."<br>";
    echo "Final Ticket Price:".$finalticketprice."<br>";



    //Arrays
    echo"<h1>Arrays</h1>";
    echo "<h3>Simple Arrays</h3>";

    $products=['t-shirt','cap','mug'];
    print_r($products);
    echo"<br>";
    $products[1]='shirt';
    print_r($products);
    $products[]='skirt';
    echo"<br>";
    print_r($products);
    echo"<br>";

    echo"<p>Items in my products array</p>";
    echo"<p>The item at index[2] is: <i>{$products[2]}</i></p>";
    echo"<p>The item at index[3] is: <i>{$products[3]}</i></p>";


    //Associative Array
    echo"<h3>Associative Arrays</h3>";

    $customer=array(
        'CustID'=>12, 
        'CustName'=>'Sarah', 
        'CustAge'=>23, 
        'CustGender'=>'F',
    );
    print_r($customer);
    $customer['CustAge']=32;
    $customer['CustEmail']='sarah@gmail.com';
    print_r($customer);

    
    echo"<p>Items in my customer array</p>";
    echo"<p>The item at index[CustName] is: <i>{$customer['CustName']}</i></p>";
    echo"<p>The item at index[CustEmail] is: <i>{$customer['CustEmail']}</i></p>";


//Additional Task
//Multi-Dimensional Array
    echo"<h3>Multi-Dimensional Arrays</h3>";
    $stock = array(
        'id1' => array(
            'description' => 't-shirt',
            'price' => 9.99,
            'stock' => 100,
            'colour' => array('blue', 'green', 'red')
        ),
        'id2' => array(
            'description' => 'cap',
            'price' => 4.99,
            'stock' => 50,
            'colour' => array('blue', 'grey', 'black')
        ),
        'id3' => array(
            'description' => 'mug',
            'price' => 6.99,
            'stock' => 30,
            'colour' => array('yellow', 'green', 'pink')
        )
    );
    
    
    print_r($stock);
    echo"<br>";
    echo"<br>";

    echo "This is my order";
    echo"<br>";
    foreach ($stock as $product) {
        $description = $product['description'];
        $colour = $product['colour'][1]; 
        $price = $product['price'];
    
        echo "$colour $description <br>";
        echo "Price: £$price<br>";

        
    }
    


    //While Loops
    echo"<h3>While Loop</h3>";
    $counter=1;
    while ($counter <= 5){
        echo "count = $counter <br>";
        $counter++;
    }

    echo"<br>";
    echo"<br>";
$shirtPrice=9.99;
$counter=1;
echo '<table border="1">
                  <tr>
                     <th>Quantity</th>
                     <th>Price</th>
                  </tr>';
while($counter<=10){
    $total=$counter*$shirtPrice;
    echo'<tr>
    <td>'.$counter.'</td>
    <td>£'.number_format($total,2).'</td>
    </tr>';
    $counter++;
}
echo'</table>';


//For Loops
echo"<h3>For Loop</h3>";
$names=array("Yunisha","Devraj","Devi","Yuki","Unesh");
for($i=0;$i<5;$i++){
    echo $names[$i]."<br>";
}

//For-Each Loops
echo"<h3>For-Each Loops</h3>";

$studentnames=array(
    "Yunisha"=>"c37691",
    "Devraj"=>"c99380",
    "Devi"=>"c46187",
    "Yuki"=>"c432121",
    "Unesh"=>"c344832",
    );
    foreach ($studentnames as $key => $value) {
        echo "Name:$key, ID: $value.<br>";
        }

//Additional Exercise
$city=array('Peter'=>'LEEDS','Kat'=>'bradford','Laura'=>'wakeFIeld');
print_r($city);
echo"<br>";
foreach ($city as $key => $value) {
    $city[$key]=ucfirst(strtolower($value));
    }
    print_r($city);

        ?>
      </section>
      <footer>   
         <small> <a href='portfolio.html'>Home</a></small>
      </footer>
   </body>
</html>
