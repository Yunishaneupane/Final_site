<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Processing Input from HTML Forms</h1>
<h2>Login Form using GET</h2>
<form method="GET" action="">
<fieldset>
	<legend>Login</legend>
	<label for="email">Email: </label>
	<input type="text" name="txtEmail"/><br />
	<label for="passwd">Password: </label>
	<input type="password" name="txtPass" /><br />
	<input type="submit" value="Submit" name="loginSubmit"  />
	<input type="reset" value="Clear" />
</fieldset>
</form>

<legend>Comments</legend>
<form method="POST" action="">
	<label for="email">Email: </label>
	<input type="text" name="txtEmail" value="<?php
		if(isset($_POST['txtEmail'])){
			echo htmlspecialchars($_POST['txtEmail']);
		}
	?>" /><br />
	<textarea rows="4" cols="50" name="txtComments"><?php
		if(isset($_POST['txtComments'])){
			echo htmlspecialchars($_POST['txtComments']);
		}
	?></textarea><br />
	<label for="confirm">Click to Confirm: </label>
	<input type="checkbox" name="chkConfirm" value="agree"><br />
	<input type="submit" value="Submit" name="commentSubmit"/>
	<input type="reset" value="Clear" />
</form>

<?php 
if(isset($_GET['loginSubmit'])){
	$email=$_GET['txtEmail'];
	$pass = $_GET['txtPass'];
	echo "<p>Email:$email Password:$pass</p>";
}

if(isset($_POST['commentSubmit'])){
	if(!empty($_POST['txtEmail'])){
		$email=$_POST['txtEmail'];
		$comments=$_POST['txtComments'];

		if(isset($_POST['chkConfirm'])){
			$confirm="Agreed<br>";
		} else {
			$confirm="Not Agreed<br>";
		}

		echo "<p>Email:$email<br> Comments:$comments<br>Confirmation: $confirm</p>";
	} else {
		echo 'Email must not be empty';
	}
}

// Validation for email
if(isset($_POST['commentSubmit'])){
	if(!empty($_POST['txtEmail'])){
		$email=$_POST['txtEmail'];
		if(filter_var($email,FILTER_VALIDATE_EMAIL)){
			$comments=$_POST['txtComments'];
			if(isset($_POST['chkConfirm'])){
				$confirm="Agreed<br>";
			} else {
				$confirm="Not Agreed<br>";
			}
			echo "<p>Email:".htmlspecialchars($email)."<br>Comments:".htmlspecialchars($comments)."<br>Confirmation:$confirm</p>";
		}
		else{
			echo "Invalid email format";
		}
	}
	else{
		echo "Email must not be empty";
	}
}

?>

<h2>Tax Calculator</h2>
<form method="POST" action="">
	<fieldset>
	<legend>Without Tax calculator</legend>
    <label for="afterTax">After Tax Price: </label>
    <input type="text" name="afterTax" value="<?php
        if(isset($_POST['afterTax'])){
            echo htmlspecialchars($_POST['afterTax']);
        }
    ?>" />
    <label for="taxRate">Tax Rate: </label>
    <input type="text" name="taxRate" value="<?php
        if(isset($_POST['taxRate'])){
            echo htmlspecialchars($_POST['taxRate']);
        }
    ?>" />
	  <input type="submit" value="Submit" name="calculateSubmit"/>
	<input type="reset" value="Clear" />
</fieldset>
  
</form>

<?php
if(isset($_POST['calculateSubmit'])){
    if(!empty($_POST['afterTax']) && !empty($_POST['taxRate'])){
        $afterTax = $_POST['afterTax'];
        $taxRate = $_POST['taxRate'];

        // Validate numeric values
        if(is_numeric($afterTax) && is_numeric($taxRate)){
            // Validate two decimal places in the price
            if(preg_match('/^\d+(\.\d{2})?$/', $afterTax)){
                $beforeTax = $afterTax * (100 / (100 + $taxRate));
                echo "<p>Price before Tax:  £ $beforeTax</p>";
            } else {
                echo 'Invalid Price format. Please enter the price in the format 9.99';
            }
        } else {
            echo 'Invalid Price or Tax Rate entered';
        }
    } else {
        echo 'All Fields Required';
    }
}
?>


<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>


    
<h1>Passing Data Appended to an URL</h1>
<h2>Pick a category</h2>
<a href="forms.php?cat=Films">Films</a>
<a href=" forms.php?cat=Books">Books</a>
<a href=" forms.php?cat=Music">Music</a>


    <?php
    // Trap using isset to ensure no output until one of the links is selected
    if(isset($_GET['cat'])){
        $selectedCategory = $_GET['cat'];
        echo "<p>Selected Category: $selectedCategory</p>";
    }
    ?>



</body>
</html>
