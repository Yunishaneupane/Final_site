<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THE TRANQUIL - HOME</title>

    <?php require('include/links.php'); ?>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    <style>
        .avaibility-form {
            margin-top: -50px;
            z-index: 2;
            position: relative;
        }

        @media screen and (max-width: 575px) {
            .avaibility-form {
                margin-top: 25px;
                padding: 0 35px;
            }
        }
    </style>

</head>

<body class="bg-light">

    <?php require('include/header.php');

    ?>

    <!------------------------- Carousel ------------------------------------------->
    <div class="container-fluid px-lg-4 mt-4">
        <div class="swiper swiper-container">
            <div class="swiper-wrapper">
                <?php
                $res = selectAll('carousel');
                while ($row = mysqli_fetch_assoc($res))
                {
                    $path = CAROUSEL_IMG_PATH;
                    echo <<<data
                        <div class="swiper-slide">
                            <img src="$path$row[image]" class="w-100 d-block">
                        </div>
                    data;
                }
                ?>
            </div>
        </div>

    </div>






    <!-------------------------------------------------- Home Picture -------------------------------------------->
    <div class="container-fluid px-lg-4 mt-4">
        <div class="swiper swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="images/front/o.jpg" width="1500" height="500" />
                </div>
                <div class="swiper-slide">
                    <img src="images/front/p.jpg" width="1500" height="500" />
                </div>
                <div class="swiper-slide">
                    <img src="images/front/q.jpg" width="1500" height="500" />
                </div>
                <div class="swiper-slide">
                    <img src="images/front/y.jpg" width="1500" height="500" />
                </div>
            </div>
        </div>
    </div>

    <!--------------------------------------------- Check availability form -------------------------------------->
    <div class="container avaibility-form">
        <div class="row">
            <div class="col-lg-12 bg-white shadow p-4 rounded">
                <h6 class="mb-4">Check Booking Availability</h6>
                <form>
                    <div class="row align-items-end">
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight:500;">Check-in</label>
                            <input type="date" class="form-control">
                        </div>

                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight:500;">Check-out</label>
                            <input type="date" class="form-control">
                        </div>

                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight:500;">Adult</label>
                            <select class="form-select" aria-label="Default select example">
                                <option selected>Open this select menu</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                        <div class="col-lg-2 mb-3">
                            <label class="form-label" style="font-weight:500;">Children</label>
                            <select class="form-select" aria-label="Default select example">
                                <option selected>Open this select menu</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                        <div class="col-lg-1 mb-lg-3 mt-2">
                            <button type="submit" class="btn text-white custom-bg">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-------------------------------------------------- Our Rooms ----------------------------------------------->
    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-fonr">OUR ROOMS</h2>
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-4 col-md-6 my-3">
                <div class="card border-0 shadow" style="max-width:350px; margin:auto;">
                    <img src="images/front/room5.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5>Standard Room</h5>
                        <h6 class="mb-4"> ₹2000 per night</h6>

                        <div class="features mb-3">
                            <h6 class="mb-1">Features</h6>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                2 Rooms
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                1 Bathroom
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                1 Balcony
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Sofa set
                            </span>
                        </div>

                        <div class="facilities mb-3">
                            <h6 class="mb-1">Facilities</h6>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Wi-Fi
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Television
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                AC
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Mini-Fridge
                            </span>
                        </div>
                        <div class="guests mb-3">
                            <h6 class="mb-1">Guests</h6>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                5 Adults
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                4 Childrens
                            </span>
                        </div>

                        <div class="rating mb-3">
                            <h6 class="mb-1">Rating</h6>
                            <span class="badge rounded-pill bg-light">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </span>
                        </div>

                        <div class="d-grid gap-2">
                            <a href="#" class="btn btn-sm text-white custom-bg">Book Now</a>
                            <a href="#" class="btn btn-sm btn-outline-dark">More details</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 my-3">
                <div class="card border-0 shadow" style="max-width:350px; margin:auto;">
                    <img src="images/front/room3.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5>Deluxe Room</h5>
                        <h6 class="mb-4"> ₹2000 per night</h6>

                        <div class="features mb-3">
                            <h6 class="mb-1">Features</h6>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                2 Rooms
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                1 Bathroom
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                1 Balcony
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Sofa set
                            </span>
                        </div>

                        <div class="facilities mb-3">
                            <h6 class="mb-1">Facilities</h6>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Wi-Fi
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Television
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                AC
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Mini-Fridge
                            </span>
                        </div>
                        <div class="guests mb-3">
                            <h6 class="mb-1">Guests</h6>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                5 Adults
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                4 Childrens
                            </span>
                        </div>

                        <div class="rating mb-3">
                            <h6 class="mb-1">Rating</h6>
                            <span class="badge rounded-pill bg-light">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </span>
                        </div>

                        <div class="d-grid gap-2">
                            <a href="#" class="btn btn-sm text-white custom-bg">Book Now</a>
                            <a href="#" class="btn btn-sm btn-outline-dark">More details</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 my-3">
                <div class="card border-0 shadow" style="max-width:350px; margin:auto;">
                    <img src="images/front/room1.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5>Suite</h5>
                        <h6 class="mb-4"> ₹2000 per night</h6>

                        <div class="features mb-3">
                            <h6 class="mb-1">Features</h6>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                2 Rooms
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                1 Bathroom
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                1 Balcony
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Sofa set
                            </span>
                        </div>

                        <div class="facilities mb-3">
                            <h6 class="mb-1">Facilities</h6>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Wi-Fi
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Television
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                AC
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                Mini-Fridge
                            </span>
                        </div>
                        <div class="guests mb-3">
                            <h6 class="mb-1">Guests</h6>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                5 Adults
                            </span>
                            <span class="badge text-bg-light text-dark mb-2 text-wrap lh-base">
                                4 Childrens
                            </span>
                        </div>

                        <div class="rating mb-3">
                            <h6 class="mb-1">Rating</h6>
                            <span class="badge rounded-pill bg-light">
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                                <i class="bi bi-star-fill text-warning"></i>
                            </span>
                        </div>

                        <div class="d-grid gap-2">
                            <a href="#" class="btn btn-sm text-white custom-bg">Book Now</a>
                            <a href="#" class="btn btn-sm btn-outline-dark">More details</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12 text-center mt-5">
                <a href="#" class="btn btn-sm btn-outline-dark rounded-0 fw-bold">More Rooms >>></a>
            </div>
        </div>
    </div>

</body>

</html>
</div>
<!--------------------------------------FACILITIES------------------------------------>
<h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-fonr">OUR FACILITIES</h2>
<div class="container">
    <div class="row justify-content-evenly px-lg-0 px-md-0 px-5">
        <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
            <img src="images/features/wifi.svg" width="80px">
            <h5 class="mt-3">Wi-Fi</h5>
        </div>
        <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
            <img src="images/features/star.svg" width="80px">
            <h5 class="mt-3">Wi-Fi</h5>
        </div>
        <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
            <img src="images/features/wifi.svg" width="80px">
            <h5 class="mt-3">Wi-Fi</h5>
        </div>
        <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
            <img src="images/features/wifi.svg" width="80px">
            <h5 class="mt-3">Wi-Fi</h5>
        </div>
        <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
            <img src="images/features/wifi.svg" width="80px">
            <h5 class="mt-3">Wi-Fi</h5>
        </div>
        <div class="col-lg-12 text-center mt-5">
            <a href="#" class="btn btn-sm btn-outline-dark rounded-0 fw-bold">More Facilities >>></a>
        </div>
    </div>
</div>

<!-----------------------------------------Testimonials/Reviews------------------------------------------->
<h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-fonr">TESTIMONIALS</h2>
<!-- Swiper -->
<div class="container mt-5">
    <div class="swiper swiper-testimonials">
        <div class="swiper-wrapper mb-5">

            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="images/features/star.png" width="30px">
                    <h6 class="m-0 ms-2">Sujit Gyawali</h6>
                </div>
                <p>Exquisite rooms, impeccable service! Our stay was a blend of comfort and luxury.
                    A hotel that truly exceeds expectations, providing an unforgettable experience in
                    refined surroundings.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="images/features/star.png" width="30px">
                    <h6 class="m-0 ms-2">Ayushma Bhandari</h6>
                </div>
                <p>Exceptional hospitality and breathtaking views. Immerse yourself in luxury with modern
                    amenities and friendly staff.A stay that defines relaxation and elegance, leaving a
                    lasting impression.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>

            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="images/features/star.png" width="30px">
                    <h6 class="m-0 ms-2">Alisha Poudel</h6>
                </div>
                <p>Modern amenities, friendly staff. A perfect escape! Our stay was delightful,
                    offering serenity and sophistication. Experience comfort and style in every
                    detail of this charming hotel.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="images/features/star.png" width="30px">
                    <h6 class="m-0 ms-2">Aayush Adhikari</h6>
                </div>
                <p>Unmatched elegance and comfort. The epitome of luxury living. Impeccable service
                    and stunning surroundings make this hotel unforgettable, ensuring a memorable
                    and delightful experience for every guest.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="images/features/star.png" width="30px">
                    <h6 class="m-0 ms-2">Manoj Panta</h6>
                </div>
                <p>A hidden gem! Charming decor, attentive staff. Every detail is perfection.
                    A stay that promises serenity and indulgence, creating a memorable and
                    enchanting experience for discerning travelers.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="images/features/star.png" width="30px">
                    <h6 class="m-0 ms-2">Anshu Kharel</h6>
                </div>
                <p>Tranquil ambiance, plush accommodations. An oasis of calm in the heart of the city.
                    A stay that redefines relaxation, offering a perfect balance of sophistication
                    and serenity.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
        </div>
        <div class="swiper-pagination"></div>
    </div>
    <div class="col-lg-12 text-center mt-5">
        <a href="#" class="btn btn-sm btn-outline-dark rounded-0 fw-bold">Know More>>></a>
    </div>
</div>

<!--------------------------------------Reach Us------------------------------------>


<h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-fonr">REACH US</h2>

<div class="container">
    <div class="row">
        <div class="col-lg-8 col-md-8 p-4 mb-lg-0 mb-3 bg-white rounded">
            <iframe class="w-100 rounded" height="320px" src="<?php echo $contact_r['iframe'] ?>" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="col-lg-4 col-md-4">
            <div class="bg-white p-4 rounded mb-4">
                <h5>Call Us</h5>
                <a href="tel:+<?php echo $contact_r['pn1'] ?>"
                    class="d-inline-block mb-2 text-decoration-none text-dark">
                    <i class="bi bi-telephone-fill"></i> +
                    <?php echo $contact_r['iframe'] ?>
                </a>
                <br>
                <?php
                if ($contact_r['pn2'] != '') {
                    echo <<<data
                    <a href="tel:+$contact_r[pn2]" class="d-inline-block mb-2 text-decoration-none text-dark">
                    <i class="bi bi-telephone-fill"></i>+$contact_r[pn2]
                    </a>
                    data;
                }

                ?>
            </div>
            <div class="bg-white p-4 rounded mb-4">
                <h5>Follow Us</h5>
                <a href="#" class="d-inline-block mb-3">
                    <span class="badge bg-light text-dark fs-6 p-2">
                        <i class="bi bi-facebook me-1"></i> Facebook
                    </span>
                </a>
                <br>
                <a href="#" class="d-inline-block mb-3">
                    <span class="badge bg-light text-dark fs-6 p-2">
                        <i class="bi bi-instagram me-1"></i> Instagram
                    </span>
                </a>
                <br>
                <a href="#" class="d-inline-block mb-3">
                    <span class="badge bg-light text-dark fs-6 p-2">
                        <i class="bi bi-twitter me-1"></i> Twitter
                    </span>
                </a>
            </div>

        </div>

    </div>
</div>

<?php require('include/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var swiper = new Swiper(".swiper-container", {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });

        // Pause autoplay on touch
        swiper.on('touchStart', function () {
            swiper.autoplay.stop();
        });

        // Resume autoplay on touch end
        swiper.on('touchEnd', function () {
            swiper.autoplay.start();
        });

        var testimonialsSwiper = new Swiper(".swiper-testimonials", {
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto",
            coverflowEffect: {
                rotate: 50,
                stretch: 0,
                depth: 100,
                modifier: 1,
                slideShadows: true,
            },
            pagination: {
                el: ".swiper-pagination",
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 3,
                },
            },
        });
    });
</script>
</body>

</html>